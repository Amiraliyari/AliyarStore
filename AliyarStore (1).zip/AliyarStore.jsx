
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingCart } from "lucide-react";

export default function AliyarStore() {
  return (
    <div className="bg-white min-h-screen p-4 font-sans">
      <header className="bg-blue-600 text-white p-4 rounded-2xl mb-6">
        <h1 className="text-3xl font-bold">فروشگاه آلیار</h1>
        <p className="text-sm mt-2">موبایل و لوازم جانبی با بهترین قیمت</p>
      </header>

      <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6].map((item) => (
          <Card key={item} className="rounded-2xl shadow p-2">
            <CardContent className="space-y-2">
              <div className="h-40 bg-gray-200 rounded-xl"></div>
              <h2 className="text-xl font-semibold">نام محصول</h2>
              <p className="text-sm text-gray-600">توضیح کوتاه محصول</p>
              <div className="flex justify-between items-center">
                <span className="text-blue-600 font-bold">۵٬۰۰۰٬۰۰۰ تومان</span>
                <Button className="rounded-full px-4 py-2 flex items-center gap-2">
                  <ShoppingCart size={16} /> افزودن به سبد
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </section>
    </div>
  );
}
